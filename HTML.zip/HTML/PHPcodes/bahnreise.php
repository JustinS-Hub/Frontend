<?php 
// spl_autoload_register(function($Bahnreise){
	// require_once("Klasse-bahnreise.inc.php");
	
// });



// $reise1 = new Bahnreise(1000, "köln", 15.0);			//Erstellung eines Bahnreise-Objektes

// echo"<br />Reisenummer: " . $reise1->HoleReiseNr();		//Ausgabe der Standardwerte der Attribute
// echo"<br />Zielort: ". $reise1->HoleZielOrt();
// echo"<br />Reisepreis: ".$reise1->HoleReisePreis();

// $reise1-> SetzeReiseNr(1000);							//ändern des Attributes Reisenummer
// $reise1 -> SetzeZielOrt("Rom");							//ändern des Attributes Zielort
// $reise1 -> SetzeReisePreis(750.0);						//ändern des Attributes Reisepreis

// echo"<br />Reisenummer: " . $reise1->HoleReiseNr();		//Ausgabe der neuen Werte der Attribute
// echo"<br />Zielort: ". $reise1->HoleZielOrt();
// echo"<br />Reisepreis: ".$reise1->HoleReisePreis();

// unset($reise1);											
// echo"<br />Hier könnten weiter Anweisungen des Skriptsfolgen."



?>