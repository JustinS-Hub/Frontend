<?php 
class Bahnreise{										// Initalisierung der Klasse Bahnreise
	
}

?>