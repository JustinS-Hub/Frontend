<?php
	function textausgabe(){
			echo "<p><mark>Dieser Text wurde mit einer Funktion umgesetzt.</mark></p>";
	}
	textausgabe();
?>