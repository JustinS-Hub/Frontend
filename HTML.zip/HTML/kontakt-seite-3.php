<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8">
		<link rel="stylesheet" href="Stylesheets\mystyle.css">
		<link rel="stylesheet" href="Stylesheets\kontakt-seite-2.css">
		<link rel="icon" href="images/pc.png">
		<title>Kontakt</title>
	</head>
	<body>
		<div>
			<img src="Images/PCh1.png" id="headerImgL" >
			<div class="header">
				Compu-GmbH
			</div>
			<img src="Images/PCh1.png" id="headerImgR">
		</div>
		<div class="floatBruch">
			<div class="menue">
				<a href="index.html">
					<div class="menueUnterpunkte">
						Home
					</div>
				</a>	
				<a href="Leistung.html">
					<div class="menueUnterpunkte">
						Leistungen
					</div>
				</a>
				<a href="kontakt.php">
					<div class="menueUnterpunkte"  id="aktuelleSeite">
						PHP-Spielerei
					</div>
				</a>				
				<a href="UeberUns.html">
					<div class="menueUnterpunkte">
						&Uuml;ber uns
					</div>
				</a>
				<a href="Impressum.html">
					<div class="menueUnterpunkte">
						Impressum
					</div>
				</a>
			</div>
		</div>
			<!------------------------------------------------------------------------------->
		<div class="phpInhalt">	

			</div>
			<div id="seitenZahl">
				Seite<br/> <a href="kontakt.php">1</a> <a href="kontakt-seite-2.php">2</a> 3
			</div>		
		</div>
	</body>
</html>